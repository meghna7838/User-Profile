// Create About component here to display the a small content here.
// In this component use paragraph tag (p) to display the content
import { Component } from "react";

class About extends Component{
    render(){
        return(
            <>
            <p> 
              Hi, my name is Pranav. I am a full stack developer
              and I have deployed several projects with MERN stack.
              I am also familiar with python and Django.
            </p>
            </>
        )
    }
}

export default About;