// Create Skill component here to display your skills
// In this component there should be a list with each listitem as your skill.